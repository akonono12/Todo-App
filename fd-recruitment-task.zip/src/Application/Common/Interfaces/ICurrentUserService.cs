﻿namespace Todo_App.Application.Common.Interfaces;

public interface ICurrentUserService
{
    string? UserId { get; }
}
