﻿using Microsoft.AspNetCore.Identity;
using Todo_App.Application.Common.Models;

namespace Todo_App.Infrastructure.Identity;

public static class IdentityResultExtensions
{
    public static Result ToApplicationResult(this IdentityResult result)
    {
        return result.Succeeded
            ? Result.Success()
            : Result.Failure(result.Errors.Select(e => e.Description));
    }
}
