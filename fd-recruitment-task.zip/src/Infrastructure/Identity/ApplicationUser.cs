﻿using Microsoft.AspNetCore.Identity;

namespace Todo_App.Infrastructure.Identity;

public class ApplicationUser : IdentityUser
{
}
