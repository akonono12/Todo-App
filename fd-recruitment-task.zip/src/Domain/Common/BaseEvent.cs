﻿using MediatR;

namespace Todo_App.Domain.Common;

public abstract class BaseEvent : INotification
{
}
