﻿global using BoDi;
global using FluentAssertions;
global using Microsoft.Playwright;
global using TechTalk.SpecFlow;
global using Todo_App.WebUI.AcceptanceTests.Pages;
